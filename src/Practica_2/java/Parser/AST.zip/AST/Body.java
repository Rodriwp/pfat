package AST;

public class Body implements Sentencia {
	public final Sentencia sent;

	public Body(Sentencia sent) {
		this.sent = sent;
	}
}
