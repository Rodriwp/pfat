package AST;

public interface Cond {
}
