package AST;

public interface Exp {
}
