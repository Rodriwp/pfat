package AST;

public class ExpBoolean implements Exp {
	public final boolean valor;

        public ExpBoolean(boolean valor) {
		this.valor = valor;
	}
}
