package AST;

public class ExpEntero implements Exp {
	public final int valor;

        public ExpEntero(int valor) {
		this.valor = valor;
	}
}
