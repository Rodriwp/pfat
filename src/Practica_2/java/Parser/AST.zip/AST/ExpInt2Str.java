package AST;

public class ExpInt2Str implements Exp {
	public final Exp exp;

        public ExpInt2Str(Exp exp) {
		this.exp = exp;
	}

}
