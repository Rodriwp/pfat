package AST;

public class ExpOpuesto implements Exp {
	public final Exp exp;

        public ExpOpuesto(Exp exp) {
		this.exp = exp;
	}

}
