package AST;

public class ExpStr2Int implements Exp {
	public final Exp exp;

        public ExpStr2Int(Exp exp) {
		this.exp = exp;
	}
}
