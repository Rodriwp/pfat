package AST;

public class ExpString implements Exp {
	public final String valor;

        public ExpString(String valor) {
		this.valor = valor;
	}
}
