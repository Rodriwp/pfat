package AST;

public interface LVar {
}
