package AST;

public class LVar1 implements LVar {
	public final String ident;

	public LVar1(String ident) {
		this.ident = ident;
	}
}
