package AST;

public class Print {
	public final Exp exp;

	public Print(Exp exp) {
		this.exp = exp;
	}
}
