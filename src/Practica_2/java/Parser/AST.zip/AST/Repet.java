package AST;

public class Repet {
	public final Exp exp;
	public final Sentencia sent;

	public Repet(Exp exp, Sentencia sent) {
		this.exp = exp;
		this.sent = sent;
	}
}
