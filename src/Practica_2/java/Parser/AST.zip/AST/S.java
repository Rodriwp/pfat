package AST;

public interface S {
}
