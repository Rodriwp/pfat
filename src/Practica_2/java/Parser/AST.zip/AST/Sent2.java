package AST;

public class Sent2 implements Sentencia {
	public final Sentencia sentlist;

	public Sent2(Sentencia sentlist) {
		this.sentlist = sentlist;
	}
}
