package AST;

public class SentList1 implements Sentencia {
	public final Sentencia sentsimp;

	public SentList1(Sentencia sentsimp) {
		this.sentsimp = sentsimp;
	}
}
