package AST;

public class SentSimp1 implements Sentencia {
	public final Asign asign;

	public SentSimp1(Asign asign) {
		this.asign = asign;
	}
}
