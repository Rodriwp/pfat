package AST;

public class SentSimp2 implements Sentencia {
	public final Cond cond;

	public SentSimp2(Cond cond) {
		this.cond = cond;
	}
}
