package AST;

public class SentSimp3 implements Sentencia {
	public final Repet repet;

	public SentSimp3(Repet repet) {
		this.repet = repet;
	}
}
