package AST;

public class SentSimp4 implements Sentencia {
	public final Print print;

	public SentSimp4(Print print) {
		this.print = print;
	}
}
