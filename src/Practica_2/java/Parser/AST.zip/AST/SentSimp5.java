package AST;

public class SentSimp5 implements Sentencia {
	public final int valor;

	public SentSimp5(int valor) {
		this.valor = valor;
	}
}
