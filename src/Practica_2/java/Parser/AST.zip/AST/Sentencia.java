package AST;

public interface Sentencia {
}
