package AST;

public interface VDef {
}
