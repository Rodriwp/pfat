package AST;

public class VDef1 implements VDef {
	public final Decl decl;

	public VDef1(Decl decl) {
		this.decl = decl;
	}
}
